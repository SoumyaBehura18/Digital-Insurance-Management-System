package tech.zeta.mavericks.digital_insurance_management_system.exceptions;

public class ClaimSubmissionException extends RuntimeException {
    public ClaimSubmissionException(String message) {
        super(message);
    }
}
