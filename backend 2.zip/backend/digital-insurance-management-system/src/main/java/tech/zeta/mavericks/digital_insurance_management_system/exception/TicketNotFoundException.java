package tech.zeta.mavericks.digital_insurance_management_system.exception;

public class TicketNotFoundException  extends  RuntimeException{

    public TicketNotFoundException(String message){
        super(message);
    }

}
