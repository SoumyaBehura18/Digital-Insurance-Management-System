package tech.zeta.mavericks.digital_insurance_management_system.enums;

public enum RoleType {
    ADMIN, USER


}
