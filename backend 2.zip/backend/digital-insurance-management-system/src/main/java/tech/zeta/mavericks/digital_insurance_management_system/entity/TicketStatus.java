package tech.zeta.mavericks.digital_insurance_management_system.entity;

public enum TicketStatus {
    OPEN,
    RESOLVED,
    CLOSED
}
