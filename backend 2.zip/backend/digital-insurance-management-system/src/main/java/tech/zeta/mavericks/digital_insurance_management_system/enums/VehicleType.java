package tech.zeta.mavericks.digital_insurance_management_system.enums;

public enum VehicleType {
    NULL, CAR, BIKE, HEAVY_VEHICLE
}
