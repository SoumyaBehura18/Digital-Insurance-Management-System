package tech.zeta.mavericks.digital_insurance_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalInsuranceManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
